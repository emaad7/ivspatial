#!/bin/sh
cd "$(dirname "$0")"
python3 ivspatial_gui.pyw
