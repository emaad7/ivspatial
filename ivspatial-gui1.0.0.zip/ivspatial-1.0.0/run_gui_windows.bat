@echo off
cd /d "%~dp0"
python ivspatial_gui.pyw
if errorlevel 1 py ivspatial_gui.pyw
